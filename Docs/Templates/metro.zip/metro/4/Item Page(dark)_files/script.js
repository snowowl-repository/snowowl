/**
 * ------------------------------------------------------------------------
 * JA Lens Template for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - Copyrighted Commercial Software
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites:  http://www.joomlart.com -  http://www.joomlancers.com
 * This file may not be redistributed in whole or significant part.
 * ------------------------------------------------------------------------
 */
 
/**
 * General script for JA Lens template
 */
 
jQuery.noConflict();

var TouchMask = {
	handlers: [],
	isbind: 0,
	ontouch: function(){
		var result = 1;
		TouchMask.handlers.each(function(fn){
			result = fn() && result;
		});
		
		if(result){
			document.removeEvents('touchstart', TouchMask.ontouch);
			TouchMask.isbind = 0;
		}
	},
	
	show: function(){
		if(this.isbind){
			return false;
		}
		
		document.addEvent('touchstart', this.ontouch);
		
		this.isbind = 1;
	},
	register: function(handler){
		if(typeOf (handler) == 'function' && Array.from(this.handlers).indexOf(handler) == -1){
			this.handlers.push(handler);
		}
	},
	unregister: function(handler){
		this.handlers.erase(handler);
	}
};

var JawallMenu = {
	initialize: function(){
		JawallMenu.isTouch = 'ontouchstart' in window && !(/hp-tablet/gi).test(navigator.appVersion);
		JawallMenu.enableTablet();
		JawallMenu.check();
		window.addEvent('resize', JawallMenu.check);
	},
	
	enableTablet: function(){
		if (JawallMenu.isTouch && window.innerWidth > 720){
			var jmainnav = $('mainnav');
			
			if(!jmainnav){
				return false;
			}
			
			var	jmenu = jmainnav.getElement('.menu');
			if(!jmenu){
				return false;
			}
			
			var	jitems = jmenu.getElements('li.deeper'),
				onTouch = function(){
					var i, len, noclick = !this.retrieve('noclick');
 
					// reset all
					for (i = 0, len = jitems.length; i < len; ++i) {
						jitems[i].store('noclick', 0);
					}
			 
					this.store('noclick', noclick);
					this.focus();
				},
				onClick = function(e){
					if(this.retrieve('noclick')){
						e.preventDefault();
					}
				};
			
			jitems.each(function(jitem){
				jitem.addEvent('touchstart', onTouch)
					.addEvent('click', onClick)
					.store('noclick', 0);
			});
		}
	},
	
	oldWidth: 0,
	
	check: function(){
		var wwidth = window.getWidth();
		if(wwidth == JawallMenu.oldWidth){
			return;
		}
		
		JawallMenu.oldWidth = wwidth;
		
		var jmainnav = $('mainnav');
		
		if(!jmainnav){
			return;
		}
		
		var	jmenuinner = jmainnav.getElement('.menu-inner'),
			jmenu = jmainnav.getElement('.menu');
		if(!jmenuinner || !jmenu){
			return;
		}
		
		//check if we have to implement scroll
		if (jmenu.offsetWidth > jmenuinner.offsetWidth) {
			jmenu.setStyle('float', 'left');
			
			if(!window.menuIScroll){
				
				var jprev = jmainnav.getChildren('.navprev')[0] ||  new Element('a', {
						'href': 'javascript:;',
						'class': 'navprev'
					}).inject(jmainnav).addEvent('click', function(){
						if(window.menuIScroll){
							window.menuIScroll.scrollToPage('prev');
						}
						
						if(JawallMenu.jcitem){
							JawallMenu.jcitem.fireEvent('shide');
							JawallMenu.jcitem = null;
						}
					}),
					jnext = jmainnav.getChildren('.navnext')[0] ||  new Element('a', {
						'href': 'javascript:;',
						'class': 'navnext'
					}).inject(jmainnav).addEvent('click', function(){
						if(window.menuIScroll){
							window.menuIScroll.scrollToPage('next');
						}
						
						if(JawallMenu.jcitem){
							JawallMenu.jcitem.fireEvent('shide');
							JawallMenu.jcitem = null;
						}
					}),
					checkNav = function (){
						if(window.menuIScroll){
							jprev.setStyle('display', window.menuIScroll.x >= 0 ? 'none' : 'block');
							jnext.setStyle('display', (window.menuIScroll.x <= window.menuIScroll.maxScrollX) ? 'none' : 'block');
						}
					};
				
				window.menuIScroll = new iScroll(jmenuinner, {
					snap: '.menu > li',
					hScrollbar: false,
					vScrollbar: false,
					onRefresh: checkNav,
					onScrollEnd: checkNav,
					onScrollStart: function(){
						if(JawallMenu.jcitem){
							JawallMenu.jcitem.fireEvent('shide');
							JawallMenu.jcitem = null;
						}
					},
					overflow: ''
				});
				
				checkNav();
				
				var jactive = jmenu.getChildren('.active')[0];
				if(jactive){
					window.menuIScroll.scrollToElement(jactive);
				}
			}
			
			if (window.menuIScroll) {
				window.menuIScroll.refresh();
			}
		} else {
			if (window.menuIScroll) {
				window.menuIScroll.scrollTo(0, 0, 0);
			}
			
			jmenu.setStyle('float', '');
		}
		
		//check if the mobile layout, we change html structure
		if(wwidth <= 985){
			if(JawallMenu.jcitem){
				JawallMenu.jcitem.fireEvent('shide');
				JawallMenu.jcitem = null;
			}
			
			jmenuinner.setStyle('overflow', 'hidden');
			
			jmenu.getChildren('.deeper > ul').each(function(jsub){
				var jitem = jsub.getParent(),
					sid = null;
					
				jsub.store('parent', jitem).addClass('jsub').inject(jmainnav).setStyle('position', 'absolute');
				
				if(!JawallMenu.isTouch){
					//add mouse event to show/hide sub on desktop
					jitem.addEvent('mouseenter', function(e){
						clearTimeout(sid);
						
						if(jsub.getStyle('display') != 'none'){
							return false;
						} else {
						
							if(JawallMenu.jcitem && JawallMenu.jcitem != jitem){
								JawallMenu.jcitem.fireEvent('shide');
							}
						
							jsub.setStyle('display', 'block').setStyles({
								top: jmenuinner.getHeight(),
								left: Math.max(0, Math.min( window.getWidth() - jsub.getWidth(), jitem.getCoordinates().left + (JawallMenu.isTouch && window.menuIScroll ? window.menuIScroll.x : 0)))
							});
							
							jitem.addClass('over');
							
							JawallMenu.jcitem = jitem;
						}
					}).addEvent('mouseleave', function(){
						clearTimeout(sid);
						sid = setTimeout(function(){
							jitem.fireEvent('shide');
						}, 100);
					});
					
					jsub.addEvent('mouseenter', function(){
						clearTimeout(sid);
					}).addEvent('mouseleave', function(){
						clearTimeout(sid);
						sid = setTimeout(function(){
							jitem.fireEvent('shide');
						}, 100);
					});
				} else {
					//add touch event for touch device
					jitem.addEvent('touchstart', function(e){
						if(jsub.getStyle('display') == 'none'){
							e.stop();
							
							if(JawallMenu.jcitem && JawallMenu.jcitem != jitem){
								JawallMenu.jcitem.fireEvent('shide');
							}
							
							jsub.setStyle('display', 'block').setStyles({
								top: jmenuinner.getHeight(),
								left: Math.max(0, Math.min( window.getWidth() - jsub.getWidth(), jitem.getCoordinates().left + (JawallMenu.isTouch && window.menuIScroll ? window.menuIScroll.x : 0)))
							});
							
							jitem.addClass('over');
							
							JawallMenu.jcitem = jitem;
							
							TouchMask.hidetoggle();
							TouchMask.show();
						}
					});
				}
				
				jitem.addEvent('shide', function(){
					clearTimeout(sid);
					jsub.setStyle('display', 'none');
					jitem.removeClass('over');
					JawallMenu.jcitem = null;
				}).fireEvent('shide');
				
			});
			
			//only init once
			if(!JawallMenu.initTouch && JawallMenu.isTouch){
				
				jmainnav.addEvent('touchstart', function(){
					if(JawallMenu.jcitem){
						this.store('touchInside', 1);
					}
				});
				
				TouchMask.hidesub = function(){
					if(jmainnav.retrieve('touchInside')){
						jmainnav.store('touchInside', 0);
						return false;
					} else {
						if(JawallMenu.jcitem){
							JawallMenu.jcitem.fireEvent('shide');
							return false;
						}
					}
					
					return true;
				};
				
				TouchMask.register(TouchMask.hidesub);
				TouchMask.hidesub();
				
				JawallMenu.initTouch = 1;
			}
			
		} else {
			
			JawallMenu.jcitem = null;
			
			jmainnav.getChildren('.jsub').each(function(jsub){
				var jitem = jsub.retrieve('parent');
				
				jitem.removeEvents('mouseenter').removeEvents('mouseleave').removeEvents('touchstart').removeEvents('shide');
				jsub.removeProperty('style').removeEvents('mouseenter').removeEvents('mouseleave').removeClass('jsub').inject(jitem);
			});
			
			jmenuinner.setStyle('overflow', '');
		}
	}
};

var JASliderSupport = {
	inited: false,
	
	initialize: function(){
		if(window.jasliderInst && window.jasliderInst.length && !JASliderSupport.inited){
			window.jasliderInst[0]._ooptions = Object.clone(window.jasliderInst[0].options);
			
			var sid = null;
			window.addEvent('resize', function(){
				clearTimeout(sid);
				sid = setTimeout(JASliderSupport.resize, 100);
			});
			
			JASliderSupport.resize();
			
			JASliderSupport.inited = true;
		}
	},
	resize: function(){
		var instance = window.jasliderInst[0],
			ooptions = instance._ooptions,
			options = instance.options,
			
			vars = instance.vars,
			ratio = Math.min(ooptions.mainWidth, window.getWidth()) / ooptions.mainWidth,
			nwidth = Math.floor(ooptions.mainWidth * ratio),
			nheight = Math.floor(ooptions.mainHeight * ratio),
			ntwidth = Math.floor(ooptions.thumbWidth * ratio),
			ntheight = Math.floor(ooptions.thumbHeight * ratio);
			
		options.mainWidth = nwidth;
		options.mainHeight = nheight;
		options.mainWidth = nwidth;
		options.thumbWidth = ntwidth;
		options.thumbHeight = ntheight;

		vars.mainWrap.setStyles({
			'width': nwidth,
			'height': nheight
		});
		
		vars.mainItems.setStyles({
			'width': nwidth,
			'height': nheight
		});
		
		instance.initMasker();
		instance.initThumbAction();
		instance.initMainCtrlButton();
		instance.initProgressBar();
	}
};

var JASliderLiteSupport = {
	inited: false,
	
	initialize: function(){
		if(window.jassliteInst && window.jassliteInst.length && !JASliderLiteSupport.inited){
			var sid = null,
				jimage = window.jassliteInst[0].vars.jmain.getElement('img'),
				img = new Image();
				
			img.onload = JASliderLiteSupport.getInfo;
			img.src = jimage.getProperty('data-original') ?  jimage.getProperty('data-original') : jimage.src;
			
			window.addEvent('resize', function(){
				clearTimeout(sid);
				sid = setTimeout(JASliderLiteSupport.resize, 100);
			});
			
			JASliderLiteSupport.inited = true;
		}
	},
	
	getInfo: function(){
		var vars = window.jassliteInst[0].vars,
			nwidth = this.naturalWidth,
			nheight = this.naturalHeight;
			
		if(!nwidth){
			nwidth = this.width;
			nheight = this.height;
		}
		
		vars.nwidth = nwidth;
		vars.nheight = nheight;
		
		JASliderLiteSupport.resize();
	},
	
	resize: function(){
		var vars = window.jassliteInst[0].vars;
		if(vars.nwidth){
			vars.jmain.setStyle('height', Math.floor(vars.nheight / vars.nwidth * window.getWidth()));
		}
	}
};

(function($){
	var groups = {
	},
	
	handler = function (group, value) {
		// ignore user setting for page with fixed option
		if ($(document.body).hasClass ('fixed-' + group)){
			return;
		}
		
		if (value) {
			if (groups[group]['type'] == 'toggle') {
				var cvalue = $.cookie ('ja-'+group);
				if (new RegExp ('(^|\\s)' + value+'(?:\\s|$)').test(cvalue)) {
					$(document.body).removeClass (group + '-' + value);
					cvalue = cvalue.replace (new RegExp ('(^|\\s)' + value+'(?:\\s|$)', 'g'), '$1');
				} else {
					$(document.body).addClass (group + '-' + value);
					cvalue += ' ' + value;
				}
				groups[group]['val'] = cvalue;
				// update cookie
				$.cookie ('ja-'+group, cvalue, {duration: 365, path: '/'});
			} else {
				// update value & cookie
				groups[group]['val'] = value;
				$.cookie ('ja-'+group, value, {duration: 365, path: '/'});
				// remove current
				document.body.className = document.body.className.replace (new RegExp ('(^|\\s)' + group+'-[^\\s]*', 'g'), '$1');
				$(document.body).addClass (group + '-' + value);
			}
		}
		
		// Make the UI reload by trigger resize event for window
		$(window).trigger('resize');
	};
	
	$.fn.toolbar = function(options){
		var defaults = {
			group: 'basegrid',
			type: 'single',
			val: 'm'
		},
		
		opt = $.extend(defaults, options);
		
		groups[opt.group] = groups[opt.group] || {};
		$extend(groups[opt.group], {type: opt.type, val: opt.val});
		
		if (!$(document.body).hasClass ('fixed-' + opt.group)){
			var value = $.cookie('ja-'+opt.group);
			if (value) {
				groups[opt.group]['val'] = value; // setting exists, replace the default
				// add active class
				$(document.body).addClass (groups[opt.group]['val'].replace (/(^|\s)([^\s]+)/g, '$1' + opt.group + '-$2'));
			} else if(opt.val) {
				handler (opt.group, opt.val);
			}
		}

		// bind event for toolbar
		return this.bind('click', function () { handler (opt.group, this.id.replace ('toolbar-' + opt.group + '-', '')); return false; });
	};
	
})($query);

(function($){
	var jcurcont = null,
		jcursub = null,
		jdim = null;
	
	$(window).bind('resize', function(){
		if(jcursub && jcursub.css('display') != 'none'){
			jcursub.css('display', 'none');
			jdim.css('display', 'none');
			
			var offs = jcurcont.offset();
			
			jcursub.css({
				display: 'block',
				top: offs.top,
				left: Math.max(0, Math.min($(window).width() - jcursub.outerWidth(true) -10,  offs.left))
			});
			
			jdim.css({
				display: 'block',
				width: $(document).width(),
				height: $(document).height()
			});
		}
	});
			
	$.fn.listbox = function(options){
		var defaults = {
		},
		
		opt = $.extend(defaults, options);
		
		// bind event for toolbar
		return this.each(function(){
			var jcontainer = $(this),
				jsub = jcontainer.find('.popup:first').css({
					display: 'none',
					opacity: 0
				});
				
			jcontainer.bind('click', function () { 
				
				if(jsub.css('display') == 'none'){
					var offs = jcontainer.offset();
					
					jsub.stop(1, 1).css({
						display: 'block',
						top: offs.top,
						left: Math.max(0, Math.min($(window).width() - jsub.outerWidth(true) -10,  offs.left))
					}).fadeTo(450, 1);
				}
				
				jdim = $('#lbdim');
				if(!jdim.length){
					jdim = $('<div id="lbdim"></div>').appendTo(document.body);
					jdim.click(function(){
						jsub.stop(1, 1).fadeTo(350, 0, function(){
							jsub.css('display', 'none');
							jcurcont = null;
							jcursub = null;
							jdim.remove();
						});
					});
				}
				
				jdim.css({
					opacity: 0,
					display: 'block',
					width: $(document).width(),
					height: $(document).height()
				}).fadeTo( 350, 0.5);
				
				jcurcont = jcontainer;
				jcursub = jsub;
			});
			
			jsub.appendTo(document.body);
		});
	};
	
})($query);

$query (function ($) {
	// enable menu responsive check
	if(!($.browser.msie && parseFloat($.browser.version) < 9)){
		JawallMenu.initialize();
	} else {
		$query(window).load(function(){
			// enable slideshow support responsive
			JASliderSupport.initialize();
			//JASliderLiteSupport.initialize();
		});
	}
	
	JASliderSupport.initialize();
	//JASliderLiteSupport.initialize();
	
	var bindevent = 'ontouchstart' in window && !(/hp-tablet/gi).test(navigator.appVersion) ? 'touchstart' : 'click',
		jtoggles = $('.btn-toggle'),
		jsearch = $('#search'),
		jtoolbar = $('#toolbar'),
		jsidebar = $('#sidebar'),
		jtoggleactive = null;
		
	// toggle handle
	jtoggles.bind(bindevent, function (event) {	
		var jactive = $(this),
			jparent = jactive.parent();
			
		if (jparent.hasClass('active')) {
			jparent.removeClass ('active');
			// remove btn-toggle-active
			jtoggleactive = null
		} else {
			// remove other active
			jtoggles.parent().removeClass ('active');
			// add active for this toggle
			jparent.addClass ('active');
			// store
			jtoggleactive = jactive;		
		}
		
		TouchMask.hidesub();
		TouchMask.show();
		
		return false;
	});
	
	jsearch.add(jtoolbar).add(jsidebar).bind(bindevent, function(){
		if(jtoggleactive){
			$(document.body).data('touchInside', 1);
		}
	});

	TouchMask.hidetoggle = function(){
		if (jtoggleactive) {
			if($(document.body).data('touchInside')){
				$(document.body).data('touchInside', 0);
				return false;
			} else {
				// remove active
				jtoggleactive.parent().removeClass ('active');
				jtoggleactive = null;
				
				return false;
			}
		}
		
		return true;
	};
	TouchMask.register(TouchMask.hidetoggle);
	
	// tracking status of btn-toggle
	$(window).resize (function() {
		if (jtoggleactive) {
			if (jtoggleactive.css('display') == 'none') {
				// remove active
				jtoggleactive.parent().removeClass ('active');
				jtoggleactive = null;
			}
		}
		
		if(jsidebar.length){
			jsidebar
				.add(jsidebar.find('.sidebar-inner'))
				.css('height', Math.max(80,  
					$(window).height()
					- (jsidebar.offset().top - $(window).scrollTop())
					- parseInt(jsidebar.css('margin-bottom'))
					- parseInt(jsidebar.css('padding-bottom'))));
		}
	});
	// scrollbar for sidebar if exist
	
	if(jsidebar.length){
		jsidebar
				.add(jsidebar.find('.sidebar-inner'))
				.css('height', Math.max(80,  
					$(window).height()
					- (jsidebar.offset().top - $(window).scrollTop())
					- parseInt(jsidebar.css('margin-bottom'))
					- parseInt(jsidebar.css('padding-bottom'))));
		window.sidebarIScroll = new iScroll(jsidebar.find('.sidebar-inner')[0], {vScrollbar: true, scrollbarClass: 'sidebarTracker', useTransform: false});
	}

	// check and load typography assert files if nessesary
	window.jtypo = $('.item-pagetypography .item-content');
	
	if(!window.jtypo.length){
		window.jtypo = $('.typography .itemBody');
	}
	
	$('#toolbar-categories, #toolbar-timeline').listbox();
});

$query(window).load(function(){
	if(window.menuIScroll){
		window.menuIScroll.refresh();
	}
	
	if(window.sidebarIScroll){
		window.sidebarIScroll.refresh();
	}
});
