/**
 * ------------------------------------------------------------------------
 * JA Lens Template for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - Copyrighted Commercial Software
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites:  http://www.joomlart.com -  http://www.joomlancers.com
 * This file may not be redistributed in whole or significant part.
 * ------------------------------------------------------------------------
 */
 
/**
 * Masonry layout for wall page
 */

 
(function($){
	var scrollSID = null,
		isTouch = 'ontouchstart' in window && !(/hp-tablet/gi).test(navigator.appVersion),
		onShow = function (e) {
			
			if ($(this).hasClass('clicked')){
				return false;
			}
			
			if ($(document.body).width() < 481){
				return true
			}
			
			e.preventDefault();
			e.stopPropagation();
			
			if($(document.body).hasClass ('popupview')){
				onHide();
				
				setTimeout($.proxy(onShow, this, e), 600);
				
				return false;
			}
			
			var jcontainer = $('#masonry-container'),
				jaction = $(this),
				jitem = jaction.closest('.item'),
				url = jaction.attr('href');
				
			// add popup class to body
			$(document.body).addClass ('popupview');				
			
			var urlparts = url.split('#');
			if(urlparts[0].indexOf('?') == -1){
				urlparts[0] += '?tmpl=component';
			} else {
				urlparts[0] += '&tmpl=component';
			}
			
			url = urlparts.join('#');
			
			jitem.addClass('clicked').append('<div class="loading"></div>');
			
			$('<div id="popup-content" style="width: 1px; height: 1px; visibility: hidden;"></div>')
				.append($('<div id="popup-head"></div>').append($('<a href="javascript:;" class="close"></a>').on('click', onHide)))
				.append($('<div id="popup-inner"></div>').append($('<iframe id="popup-iframe" src="' + url + '" height="1" width="' + (jcontainer.data ('basewidth')? jcontainer.data ('basewidth') : $('#base-blank-item').width()) * 3 + '" scrolling="no" frameborder="0" />').bind('load', ifmOnload)))
				.appendTo(jitem);
				
			//jcontainer.masonry('resize');
			
			return false;
		},
		
		ifmOnload = function(){					//function check iframe popup load to resize
			if(this.src == 'about:blank'){
				return;
			}
			
			$(document.body).addClass ('popupview-loaded');
			
			var doc = this.contentDocument ? this.contentDocument : window.frames[this.id].document,
				ifm = this;
			
			if (doc.readyState && doc.readyState != 'complete'){
			   return;
			}

			if (doc.body && doc.body.innerHTML == 'false'){
				return;
			}
			
			var jcontainer = $('#masonry-container'),
				jpcontent = $('#popup-content');
			
			jpcontent.attr('style', '').siblings('.loading').remove();
			jpcontent.siblings().hide();
			jpcontent.parent().addClass('item-popup-view grid-trible').css('width', (jcontainer.data ('basewidth')? jcontainer.data ('basewidth') : $('#base-blank-item').width()) * 3);
			
			ifm.height = $(doc).height();
			
			if(window.popupIscroll){
				window.popupIscroll.destroy();
			}
			
			window.popupIscroll = new iScroll('popup-inner', {vScrollbar: true, hScrollbar: false, scrollbarClass: 'popupTracker', fixedIndicator: true, onBeforeScrollStart: null, useTransform: false, scroller: (isTouch ? doc.getElementById('container') : null) });
			
			if(isTouch){
				$(doc).bind('touchmove.scroll', function(e){
					e.preventDefault();
				});
			}
			
			if($.browser.opera || $.browser.mozilla || ($.browser.msie && $.browser.version >= 9)){
				$(doc).bind('mousewheel.iscroll', $.proxy(window.popupIscroll._wheel, window.popupIscroll));
			} else if($.browser.msie && $.browser.version < 9){
				
				var script = doc.createElement('script');
				script.src = JADef.tplurl + 'js/scrollevent.js';
				doc.body.appendChild(script);
			} 
			
			$(doc.body).find('a').each(function(){
				if($(this).attr('target') != '_blank'){
					$(this).attr('target', '_parent');
				}
			});
			
			jcontainer.masonry('resize');
			jpcontent.css('opacity', 0);
			
			clearTimeout(scrollSID);
			scrollSID = setTimeout(function(){
				jpcontent.fadeTo(800, 1);
				
				if($.browser.opera && window.popupIscroll){
					window.popupIscroll.refresh();
				}
				
				$('html, body').stop().animate({
					scrollTop: jpcontent.offset().top
				});
			}, 550);
		},
		
		onHide = function () {
			clearTimeout(scrollSID);
			
			if(window.popupIscroll){
				window.popupIscroll.destroy();
				window.popupIscroll = null;
			}
			
			var jpcontent = $('#popup-content'),
				jiframe = $('#popup-iframe'),
				jcontainer = $('#masonry-container'),
				ifmdoc = (jiframe.length && jiframe[0].contentDocument) ? jiframe[0].contentDocument : window.frames[jiframe[0].id].document;
				
			if(isTouch){
				$(ifmdoc).unbind('touchmove.scroll');
			}
			
			if($.browser.mozilla && jiframe.length){
				$(ifmdoc).unbind('mousewheel.iscroll');
			}
			
			//fix iframe IE9
			jiframe.attr('src', 'about:blank').hide();
			
			setTimeout(function(){
				jpcontent.siblings().show().filter('.loading').remove();
				jpcontent.parent().css('width', (jcontainer.data('basewidth') ? jcontainer.data ('basewidth') : $('#base-blank-item').width())).removeClass('clicked item-popup-view grid-trible');
				jpcontent.remove();
				$(document.body).removeClass ('popupview popupview-loaded');
				jcontainer.masonry('reload');
			}, 10);
			return false;
		};
		
	window.iframeWheel = function(updown){
		if(window.popupIscroll){
			window.popupIscroll._wheel(updown);
		}
	};
		
	window.iframeResize = function(updown){
		if(window.popupIscroll){
			var jiframe = $('#popup-iframe');
			if(jiframe.length){
				var ifmdoc = (jiframe[0].contentDocument) ? jiframe[0].contentDocument : window.frames[jiframe[0].id].document;
				
				jiframe.attr('height', $(ifmdoc).height());
				window.popupIscroll.refresh();
			}
		}
	};
	
	$.fn.detail = function(options){
		var defaults = {
				selector: '.item-link'
			},
			opt = $.extend(defaults, options);
		
		return this.off('click', opt.selector).on('click', opt.selector, onShow); 
	};
	
})($query);

$query(function($){
	var $container = $('#masonry-container');
	// no masonry, quit
	if (!$container.length) return;
	
	// add a blank, invisible masonry block to get the base width
	if (!$('#base-blank-item').length) {
		$('<div id="base-blank-item" class="item" style="height:0;visibility:hidden" />').appendTo ($container);
	}
	
	$('<div id="item-more" class="item item-more"><div class="inner item-inner clearfix"><h3>Click To Load More Awesomeness...</h3></div></div>').appendTo ($container);
	
	var reloadMasonry = function (wait) {
		$container.masonry('resize');
	};		
	
	var updateWidthTimeout = 0;
	var reloadTimeout = 0;
	var updateMasonryContainerWidth = function () {
		// wrapper width
		var cw = $('#base-blank-item').css('width', '').width(),
			lcw = $container.data ('last-basewidth');
			
		$container.data ('last-basewidth', cw);
		// first time
		if (!lcw) lcw = cw;
		// wrap width
		//var w = $('#container .main').width() - 20;
		var mw = $container.width();
		var cols = Math.round(mw / cw);
		
		// update new width
		var cw_ = Math.floor ((mw) / cols);
		var mw_ = cols * cw_;
		
		$('#base-blank-item').css('width', cw_);
		
		if ($container.data('basewidth') != cw_) {
			$container.data('basewidth', cw_);
			updateBrickWidth ();
		}
		
		if (mw_ != mw) {
			// direct update container width - run faster than using jquery width
			document.getElementById('masonry-container').width = mw_;
		}
		
		// reload layout
		reloadMasonry (true);
	};
	
	var updateBrickWidth = function ($bricks) {
		if (!$bricks) $bricks = $container.find('.item');
		var cw_ = $container.data ('basewidth');
		if (!cw_) return;
		// update width for items
		$bricks.width (cw_);
		$bricks.filter('.grid-double').width(cw_*2);
		$bricks.filter('.grid-trible').width(cw_*3);
		//$container.masonry( 'option', {columnWidth: cw_} );
		
	// if style is Minimalist then convert image to grayscale
        if(typeof setGrayscale != 'undefined'){
			setGrayscale()
		}
	};

	var reloadSetting = function () {
		// update masonry colwidth
		updateMasonryContainerWidth();			
		reloadMasonry();
	};
	
	var updateYearCount = function(jnews){
		var removes = $();
			
		jnews.filter('.item-timeline').each(function(){
			var jnewline = $(this),
				jnewnum = jnewline.find('input'),
				newnum = jnewnum.val(),
				joldline = $container.children('.' + jnewnum.attr('class'));
				
			if(joldline.length > 1){
				var total = parseInt(joldline.eq(0).find('input').val()) + parseInt(newnum);
				joldline.find('input').val(total);
				joldline.find('p').html('Have ' + total + ' item' + (total > 1 ? 's' : ''));
				
				removes = removes.add(joldline.slice(1).remove());
			}
		});
		
		return jnews.not(removes);
	};
	
	// init masonry
	$container.masonry({
		itemSelector: '.item',
		isResizable: false,
		columnWidth: function() { return $container.data ('basewidth')? $container.data ('basewidth') : $('#base-blank-item').width() }
	});

	// reload masonry when image loaded
	$container.imagesLoaded(reloadMasonry);
	
	//fix gap when custom font loaded
	$(window).load(reloadMasonry);
			
	// force show scrollbar
	$('#bd').css ('min-height', $(window).height() + 10);
	
	// create your jQuery window resize method. The clearTimeout() method prevents the
	$(window).resize(function(){
		clearTimeout( updateWidthTimeout );
		updateWidthTimeout = setTimeout(updateMasonryContainerWidth, 400);
	});
	/* infinitive scroll for main masonry only */
	if ($('#masonry-container').length) {
		var pathObject = {
			init: function(){
				this.path = ($('#page-next-link').attr('href') || '');
				var match = this.path.match(/((page|start)[=-])(\d*)(&*)/i);
				if(match){
					this.type = match[2];
					this.number = match[3];
					this.limit = this.type == 'page' ? 1 : this.number;
					this.number = this.type == 'page' ? this.number : 1;
				} else {
					this.type = 'unk';
					this.number = 2;
					this.path = this.path + (this.path.indexOf('?') == -1 ? '?' : '') + 'page=';
				}
			},
			
			join: function(page){
				if(this.type == 'unk'){
					return this.path + this.number++;
				} else{
					return this.path.replace(/((page|start)[=-])(\d*)(&*)/i, '$1' + (this.limit * this.number++) + '$4');
				}
			}
		};
		
		pathObject.init();
		$container.infinitescroll({
			navSelector  : '#page-nav',    // selector for the paged navigation 
			nextSelector : '#page-next-link',  // selector for the NEXT link (to page 2)
			itemSelector : '.item',     // selector for all items you'll retrieve
			extraScrollPx: 100,
			pathParse: pathObject,
			errorCallback: function(){
				$('#item-more').unbind('click').find('h3:first').html('That\'s all we have for now :(').show();
			},
			loading: {
				selector: '#item-more .item-inner',
				finishedMsg: JADef.fmsg,
				msgText: JADef.ltext,
				img: JADef.tplurl + 'images/loader.gif'
			}
		}, function( newElements ) {
			// hide new items while they are loading
			var $newElems = $( newElements ).css({ opacity: 0 });
			// ensure that images load before adding to masonry layout
			$newElems.imagesLoaded(function(){
				// show elems now they're ready
				$newElems.animate({ opacity: 1 });
				
				//if there still more item
				if($newElems.length){
					// update bricks width
					updateBrickWidth ($newElems);
					$newElems = updateYearCount($newElems);
					
					//move item-more to the end
					$('#item-more').appendTo($container).find('h3:first').show();
					
					$newElems.css('top', $container.height());
					$container.masonry( 'reload');
				}
			});
			
			// update
			$('#item-more').appendTo($container).find('h3:first').show();
			
			// update image caption for Joomla images
			new JCaption('img.caption');
			// add click for item-link
			if(typeof lazyloadinit != 'undefined') {
				lazyloadinit();
			}
		});
		
		$(window).unbind('.infscr');
		
		$('#item-more').click(function(){
			$('h3:first', this).hide();
			$container.infinitescroll('retrieve');
		});
	}
	
	// popup preview
	if (!$(document.body).hasClass ('no-preview')) {
		$container.detail();
	}
	
	//recalculate layout
	$(window).trigger('resize');
});