/*
mod_S5_frontpageslide
Author: Shape 5 - Professional Template Community
Available for download at www.shape5.com
Copyright Shape 5 LLC
*/



/* set opacities */

function s5thumb0op() {
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0;}}

function s5thumb1op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}

function s5thumb2op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}

function s5thumb3op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}

function s5thumb4op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}

function s5thumb5op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}


function s5thumb6op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}

function s5thumb7op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}

function s5thumb8op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0;}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0;}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0;}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0;}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0;}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0;}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0;}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0;}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.opacity = 0; }}

function s5thumb9op() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.opacity = 0; }
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.opacity = 0; }
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.opacity = 0; }
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.opacity = 0; }
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.opacity = 0; }
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.opacity = 0; }
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.opacity = 0; }
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.opacity = 0; }
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.opacity = 0; } }









/*block and none */

function s5thumb0() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'block';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb1() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'block';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb2() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'block';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}


function s5thumb3() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'block';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb4() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'block';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb5() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'block';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb6() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'block';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb7() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'block';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb8() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'block';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'none';}
}

function s5thumb9() {
if (s5_ifvisible >= 1) {
document.getElementById("s5_button_item1").style.display = 'none';}
if (s5_ifvisible >= 2) {
document.getElementById("s5_button_item2").style.display = 'none';}
if (s5_ifvisible >= 3) {
document.getElementById("s5_button_item3").style.display = 'none';}
if (s5_ifvisible >= 4) {
document.getElementById("s5_button_item4").style.display = 'none';}
if (s5_ifvisible >= 5) {
document.getElementById("s5_button_item5").style.display = 'none';}
if (s5_ifvisible >= 6) {
document.getElementById("s5_button_item6").style.display = 'none';}
if (s5_ifvisible >= 7) {
document.getElementById("s5_button_item7").style.display = 'none';}
if (s5_ifvisible >= 8) {
document.getElementById("s5_button_item8").style.display = 'none';}
if (s5_ifvisible >= 9) {
document.getElementById("s5_button_item9").style.display = 'none';}
if (s5_ifvisible >= 10) {
document.getElementById("s5_button_item10").style.display = 'block';}
}




function opacity(id, opacStart, opacEnd, millisec) {
	//speed for each frame
	var speed = Math.round(millisec / 100);
	var timer = 0;
	//determine the direction for the blending, if start and end are the same nothing happens
	if(opacStart > opacEnd) {
		for(i = opacStart; i >= opacEnd; i--) {
			setTimeout("changeOpac_ts(" + i + ",'" + id + "')",(timer * speed));
			timer++;
		}
	} else if(opacStart < opacEnd) {
		for(i = opacStart; i <= opacEnd; i++)
			{
			setTimeout("changeOpac_ts(" + i + ",'" + id + "')",(timer * speed));
			timer++;
		}
	}
}

//change the opacity for different browsers
function changeOpac_ts(opacity, id) {
	var object = document.getElementById(id).style; 
	object.opacity = (opacity / 100);
	object.MozOpacity = (opacity / 100);
	object.KhtmlOpacity = (opacity / 100);
	object.filter = "alpha(opacity=" + opacity + ")";
}

function shiftOpacity_ts(id) {
	//if an element is invisible, make it visible, else make it ivisible
	if(document.getElementById(id).style.display == 'none') {
		opacity(id, 0, 100, 1000);
	} else {
		return false;
	}
}



function blendimage_ts(divid, imageid, imagefile, millisec) {
	var speed = Math.round(millisec / 100);
	var timer = 0;
	
	//set the current image as background
	document.getElementById(divid).style.backgroundImage = "url(" + document.getElementById(imageid).src + ")";
	
	//make image transparent
	changeOpac_ts(0, imageid);
	
	//make new image
	document.getElementById(imageid).src = imagefile;

	//fade in image
	for(i = 0; i <= 100; i++) {
		setTimeout("changeOpac_ts(" + i + ",'" + imageid + "')",(timer * speed));
		timer++;
	}
}

function currentOpac(id, opacEnd, millisec) {
	//standard opacity is 100
	var currentOpac = 100;
	
	//if the element has an opacity set, get it
	if(document.getElementById(id).style.opacity < 100) {
		currentOpac = document.getElementById(id).style.opacity * 100;
	}

	//call for the function that changes the opacity
	opacity(id, currentOpac, opacEnd, millisec)
}

